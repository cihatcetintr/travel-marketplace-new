# NextApp



## 💻 Nasıl Kullanılır?

1. Bu projeyi bilgisayarınıza indirin:
 
2. Proje klasörüne girin:
  
3. Gerekli programları yükleyin:

4. Projeyi çalıştırın:   
npm run dev


Tarayıcınızda `http://localhost:3000` adresine giderek projeyi görebilirsiniz.

## 🔧 Neler Gerekli?

- Node.js
- npm

## ⭐ Özellikler

## 📱 Ekran Görüntüleri

## 🤝 Nasıl Katkıda Bulunabilirsiniz?

1. Projeyi fork edin
2. Yeni bir dal oluşturun (`git checkout -b yeni-ozellik`)
3. Değişikliklerinizi kaydedin (`git commit -m 'Yeni özellik eklendi'`)
4. Değişikliklerinizi yükleyin (`git push origin yeni-ozellik`)
5. Pull request oluşturun
